## TPay 相关资料汇总

该文档用于指引开发和运维关于服务器、代码相关的维护。

| 版本 | 类别 | 维护人 | 具体说明                                   | 时间       |
| ---- | ---- | ------ | ------------------------------------------ | ---------- |
| v1.1 | M    | 杨志   | 新增前端部署方式                           | 2023-04-08 |
| v1.0 | A    | 黎进   | 新增文档，说明该文档的用意，并补充文档内容 | 2023-03-15 |

> 版本说明逆序排列，类别字段：A - 新增，M - 修改，D - 删除

### 一、运维类

#### 1、环境

| 类型     | 商户端                       | 管理后台                  |
| -------- | ---------------------------- | ------------------------- |
| 测试环境 | http://47.99.36.242          | http://47.99.36.242:18080 |
| 帐密     | 自行注册                     | 13567104180 / jll567tp    |
| 生产环境 | http://merchant.tpay123.com/ | https://boss.tpay123.com/ |
| 帐密     | 自行注册                     | 13567104180 / jll567tp    |

#### 2、服务器信息

测试环境和生产环境均维护在阿里云上，帐密如下：

地址：https://signin.aliyun.com/login.htm?callback=https%3A%2F%2Faccount.console.aliyun.com%2Fv2%2F#/main

账号：tpay@1387858211463641.onaliyun.com

密码：UHsE8Z7n1z$N9nKpXkXijsh}#BfSYSn}

| 类型      | 实例ID                 | IP                                      | 密码                   | 备注                                      |
| --------- | ---------------------- | --------------------------------------- | ---------------------- | ----------------------------------------- |
| 测试环境  | i-bp138dillaiy3w3x3q1t | 47.99.36.242(公)<br />172.16.0.89(私有) | root/yvC&ak&n1         |                                           |
| 生产环境  | i-bp1bpd8u221gwkgk1yh0 | 47.97.167.99(公)<br />172.16.0.90(私有) | root/iexRA8Q3uo2FsT1P1 |                                           |
| 测试MySQL | rm-bp14g37qnx06qzd72   | /                                       | vcc/Qwer1222@          | 需要到阿里云控制台操作（2023年5月23到期） |

阿里云AccessKey

| AccessKey ID             | AccessKey Secret               |
| ------------------------ | ------------------------------ |
| LTAI5tB5L7vKAfbqRc7HEJZz | OF8iwb0EmWBYV0UWCFkvpRX9xBhVRn |

#### 3、Java端部署方式

注意，部署前请使用远程连接服务器（XShell、苹果终端或阿里云网页端），将之前的包备份好，打上日期的tag，例如：boss-web.jar 改名为 boss-web_20230323.jar，再执行下面的步骤，以下步骤以测试环境为例。

1）MacOS（苹果）

a. 使用IDE打包编译生成jar文件后，执行下面的命令上传到服务器上：

``` shell
scp -r ./web.jar  root@47.99.36.242:/data/jar
scp -r ./boss.jar  root@47.99.36.242:/data/jar
```

b. 登录服务器，进入后端目录

``` shell
cd /data/jar
```

c. 更新商户端

``` shell
sh web-restart.sh 
```

d. 更新管理后台

``` shell
sh boss-restart.sh 
```

执行 ps -ef | grep java 命令，查看正在运行的Java程序的更新时间，是否是刚刚执行的时间，等待一会（JVM加载程序）后，可以去页面刷新，若可正常访问，说明更新成功了。

2）Windows

Windows用户可以使用XShell或者SecuryCRT将打好的包上传到服务器上，然后按照 b-c-d 步骤来更新即可。

#### 4、前端部署方式

1）MacOS（苹果）

a. 使用本地webpack打包后，将dist文件夹压缩成 rar 或 zip 包。

b. 执行以下命令上传到服务器上（注意，日期后缀请自行修改）：

``` shell
scp -r ./dist_20230408.zip  root@47.99.36.242:/data/html
scp -r ./admin_20230408.zip  root@47.99.36.242:/data/html
```

c. 登录服务器，进入前端目录

``` shell
cd /data/html
```

d. 将原环境上的前端文件删除，并解压刚刚上传的包（以更新商户端为例）

``` shell
rm -rf dist
unzip ./dist_20230408/zip
```

【注意】生产环境上的boss后台的目录是 **pro**，不是admin！

2）Windows

Windows用户可以使用XShell或者SecuryCRT将打好的包上传到服务器上，然后按照 c-d 步骤来更新即可。

#### 5、数据库直连

如果想要直连数据库进行调试和Bug排查，可以按照下面的步骤进行操作。

a. 登录阿里云管理后台（页面），选择数据库实例

b. 在左侧菜单选择 白名单与安全组

c. 点击“添加白名单分组“，并填上自己的IP地址（Windows在命令行输入 ipconfig 查找，MacOS 输入 curl ifconfig.me 即可查到本机IP）

d. 添加后，在客户端（Navicat、SequelPro等工具）进行登录了（如果不知道用户名和密码，可以去看Java的Mybatis配置）

下面是测试服的配置：

```
Host: rm-bp14g37qnx06qzd72fo.mysql.rds.aliyuncs.com
port: 3306
username: vcc_prod
password: iexRA8Q3uo2FsT1P
database: vcc_prod_card
```

### 二、开发类

#### 1、PingPong开发者平台

链接：https://developer.pingpongx.com/

账号：tpay123@163.com

密码：TPay123456

#### 2、网易邮箱

该邮箱账号用于注册pingpong开发者平台，暂时未作他用。

账号：tpay123@163.com

密码：TPay123456

### 三、产品类

#### 1、产品原型

产品原型图维护在墨刀上：

商户端：https://modao.cc/app/design/pblfahig3onbnapl

管理后台：https://modao.cc/app/design/pblfnjb384lz121q

如果没有权限，可以联系 黎进 或 吴钟添 来添加。



