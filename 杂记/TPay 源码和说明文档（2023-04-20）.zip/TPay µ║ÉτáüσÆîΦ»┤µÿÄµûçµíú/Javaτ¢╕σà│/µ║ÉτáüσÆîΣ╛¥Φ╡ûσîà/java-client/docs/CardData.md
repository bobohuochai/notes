
# CardData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**availableBalance** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]



