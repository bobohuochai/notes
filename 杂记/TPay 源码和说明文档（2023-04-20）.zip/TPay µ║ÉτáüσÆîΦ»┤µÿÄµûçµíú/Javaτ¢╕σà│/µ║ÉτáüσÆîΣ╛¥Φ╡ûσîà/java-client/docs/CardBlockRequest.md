
# CardBlockRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ppCardId** | **String** |  | 



