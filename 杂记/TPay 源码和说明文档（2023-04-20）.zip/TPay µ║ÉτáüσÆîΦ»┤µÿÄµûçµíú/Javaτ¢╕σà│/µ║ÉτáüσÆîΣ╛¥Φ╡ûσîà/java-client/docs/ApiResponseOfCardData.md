
# ApiResponseOfCardData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**CardData**](CardData.md) |  |  [optional]
**message** | **String** |  |  [optional]



