
# PageDataOfClear

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_list** | [**List&lt;Clear&gt;**](Clear.md) |  |  [optional]
**total** | **Integer** |  |  [optional]



