
# CardRemarkRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ppCardId** | **String** |  | 
**remark** | **String** |  |  [optional]



