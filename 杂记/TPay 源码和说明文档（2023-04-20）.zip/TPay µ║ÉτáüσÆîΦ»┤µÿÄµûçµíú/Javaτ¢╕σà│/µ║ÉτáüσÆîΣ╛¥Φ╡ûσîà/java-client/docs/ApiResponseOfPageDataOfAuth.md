
# ApiResponseOfPageDataOfAuth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**PageDataOfAuth**](PageDataOfAuth.md) |  |  [optional]
**message** | **String** |  |  [optional]



