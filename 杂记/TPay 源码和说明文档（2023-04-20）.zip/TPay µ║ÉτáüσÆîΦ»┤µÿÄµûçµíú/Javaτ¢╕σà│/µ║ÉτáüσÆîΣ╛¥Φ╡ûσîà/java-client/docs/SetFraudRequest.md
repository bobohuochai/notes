
# SetFraudRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mcc** | **List&lt;String&gt;** |  | 
**merchantName** | **List&lt;String&gt;** |  |  [optional]



