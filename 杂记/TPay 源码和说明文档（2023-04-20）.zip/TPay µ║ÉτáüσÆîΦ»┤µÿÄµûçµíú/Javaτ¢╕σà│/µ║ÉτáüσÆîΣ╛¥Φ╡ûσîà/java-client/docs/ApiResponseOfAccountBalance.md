
# ApiResponseOfAccountBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**AccountBalance**](AccountBalance.md) |  |  [optional]
**message** | **String** |  |  [optional]



