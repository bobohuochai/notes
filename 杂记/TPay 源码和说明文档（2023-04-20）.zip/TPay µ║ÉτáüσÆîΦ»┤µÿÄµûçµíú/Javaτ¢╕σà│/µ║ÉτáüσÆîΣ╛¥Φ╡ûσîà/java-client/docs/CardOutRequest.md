
# CardOutRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  | 
**ppCardId** | **String** |  | 
**uniqueOrderId** | **String** |  | 



