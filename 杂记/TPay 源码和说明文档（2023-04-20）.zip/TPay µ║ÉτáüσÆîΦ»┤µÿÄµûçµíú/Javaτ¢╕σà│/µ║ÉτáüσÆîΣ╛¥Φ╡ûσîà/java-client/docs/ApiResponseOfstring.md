
# ApiResponseOfstring

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



