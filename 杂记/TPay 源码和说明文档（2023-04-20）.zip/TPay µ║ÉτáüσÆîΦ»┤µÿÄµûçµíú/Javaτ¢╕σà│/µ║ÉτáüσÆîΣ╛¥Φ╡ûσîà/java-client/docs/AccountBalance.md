
# AccountBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **String** |  |  [optional]
**budgetId** | **String** |  |  [optional]
**budgetName** | **String** |  |  [optional]
**currency** | **String** |  |  [optional]



