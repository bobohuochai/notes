# PingPongIssuingOpenApiV2Api

All URIs are relative to *https://localhost:8031*

Method | HTTP request | Description
------------- | ------------- | -------------
[**applyCardUsingPOST**](PingPongIssuingOpenApiV2Api.md#applyCardUsingPOST) | **POST** /v2/vcc/open/card/apply | apply card api
[**applyForCancelUsingPOST**](PingPongIssuingOpenApiV2Api.md#applyForCancelUsingPOST) | **POST** /v2/vcc/open/card/applyForCancellation | card applyForCancellation
[**authorizationsUsingGET**](PingPongIssuingOpenApiV2Api.md#authorizationsUsingGET) | **GET** /v2/vcc/open/authorizations | query authorizations api by page
[**blockUsingPOST**](PingPongIssuingOpenApiV2Api.md#blockUsingPOST) | **POST** /v2/vcc/open/card/block | block card api
[**cardProductListUsingGET**](PingPongIssuingOpenApiV2Api.md#cardProductListUsingGET) | **GET** /v2/vcc/open/card/product | query card product
[**cardsUsingGET**](PingPongIssuingOpenApiV2Api.md#cardsUsingGET) | **GET** /v2/vcc/open/cards | query card list by page
[**chargeOutUsingPOST**](PingPongIssuingOpenApiV2Api.md#chargeOutUsingPOST) | **POST** /v2/vcc/open/card/order/charge-out | card balance fund transfer out to account balance
[**clearingsRecordUsingGET**](PingPongIssuingOpenApiV2Api.md#clearingsRecordUsingGET) | **GET** /v2/vcc/open/clearings-record | query  clearings record api by page
[**clearingsUsingGET**](PingPongIssuingOpenApiV2Api.md#clearingsUsingGET) | **GET** /v2/vcc/open/clearings | query clearings api by page
[**getAvailableBalanceByPpCardIdUsingGET**](PingPongIssuingOpenApiV2Api.md#getAvailableBalanceByPpCardIdUsingGET) | **GET** /v2/vcc/open/card/balance | query card balance by cardId
[**getFraudConfigUsingGET**](PingPongIssuingOpenApiV2Api.md#getFraudConfigUsingGET) | **GET** /v2/vcc/open/getFraud | get fraud
[**queryAccountBalance2UsingGET**](PingPongIssuingOpenApiV2Api.md#queryAccountBalance2UsingGET) | **GET** /v2/vcc/open/card/detail | query card detail by cardId
[**queryAccountBalanceUsingGET**](PingPongIssuingOpenApiV2Api.md#queryAccountBalanceUsingGET) | **GET** /v2/vcc/open/account/balance | query normal account balance
[**queryAllAccountBalanceUsingGET**](PingPongIssuingOpenApiV2Api.md#queryAllAccountBalanceUsingGET) | **GET** /v2/vcc/open/account/balance/all | query all balance
[**queryCardOrderListUsingGET**](PingPongIssuingOpenApiV2Api.md#queryCardOrderListUsingGET) | **GET** /v2/vcc/open/card/order/list | query card order list by page
[**queryShareAccountBalanceUsingGET**](PingPongIssuingOpenApiV2Api.md#queryShareAccountBalanceUsingGET) | **GET** /v2/vcc/open/account/share/balance | query normal account balance
[**rechargeUsingPOST**](PingPongIssuingOpenApiV2Api.md#rechargeUsingPOST) | **POST** /v2/vcc/open/card/order/recharge | normal card recharge
[**setFraudConfigUsingPOST**](PingPongIssuingOpenApiV2Api.md#setFraudConfigUsingPOST) | **POST** /v2/vcc/open/setFraud | set fraud
[**unblockUsingPOST**](PingPongIssuingOpenApiV2Api.md#unblockUsingPOST) | **POST** /v2/vcc/open/card/unblock | unblock card api
[**updateCardLimitUsingPOST**](PingPongIssuingOpenApiV2Api.md#updateCardLimitUsingPOST) | **POST** /v2/vcc/open/share/card/limit | update share card limit details
[**updateCardRemarkUsingPOST**](PingPongIssuingOpenApiV2Api.md#updateCardRemarkUsingPOST) | **POST** /v2/vcc/open/card/remark | update card remark


<a name="applyCardUsingPOST"></a>
# **applyCardUsingPOST**
> ApiResponseOfstring applyCardUsingPOST(authorization, request)

apply card api

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
ApplyCardRequest request = new ApplyCardRequest(); // ApplyCardRequest | request
try {
    ApiResponseOfstring result = apiInstance.applyCardUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#applyCardUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**ApplyCardRequest**](ApplyCardRequest.md)| request |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="applyForCancelUsingPOST"></a>
# **applyForCancelUsingPOST**
> ApiResponseOfstring applyForCancelUsingPOST(authorization, request)

card applyForCancellation

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
ApplyForCancelRequest request = new ApplyForCancelRequest(); // ApplyForCancelRequest | request
try {
    ApiResponseOfstring result = apiInstance.applyForCancelUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#applyForCancelUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**ApplyForCancelRequest**](ApplyForCancelRequest.md)| request |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="authorizationsUsingGET"></a>
# **authorizationsUsingGET**
> ApiResponseOfPageDataOfAuth authorizationsUsingGET(authorization, endDate, ppCardId, row, startDate, startPage)

query authorizations api by page

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String endDate = "endDate_example"; // String | endDate
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "startDate_example"; // String | startDate
Integer startPage = 56; // Integer | 
try {
    ApiResponseOfPageDataOfAuth result = apiInstance.authorizationsUsingGET(authorization, endDate, ppCardId, row, startDate, startPage);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#authorizationsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **endDate** | **String**| endDate | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**| startDate | [optional]
 **startPage** | **Integer**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfAuth**](ApiResponseOfPageDataOfAuth.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="blockUsingPOST"></a>
# **blockUsingPOST**
> ApiResponseOfVoid blockUsingPOST(authorization, cardBlockRequest)

block card api

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardBlockRequest cardBlockRequest = new CardBlockRequest(); // CardBlockRequest | cardBlockRequest
try {
    ApiResponseOfVoid result = apiInstance.blockUsingPOST(authorization, cardBlockRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#blockUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardBlockRequest** | [**CardBlockRequest**](CardBlockRequest.md)| cardBlockRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="cardProductListUsingGET"></a>
# **cardProductListUsingGET**
> ApiResponseOfListOfProduct cardProductListUsingGET(authorization, share)

query card product

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
Boolean share = true; // Boolean | 
try {
    ApiResponseOfListOfProduct result = apiInstance.cardProductListUsingGET(authorization, share);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#cardProductListUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **share** | **Boolean**|  |

### Return type

[**ApiResponseOfListOfProduct**](ApiResponseOfListOfProduct.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="cardsUsingGET"></a>
# **cardsUsingGET**
> ApiResponseOfPageDataOfCard cardsUsingGET(authorization, cardStatus, endDate, last4, remark, row, startDate, startPage, type)

query card list by page

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String cardStatus = "cardStatus_example"; // String | 
String endDate = "endDate_example"; // String | endDate
String last4 = "last4_example"; // String | 
String remark = "remark_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "startDate_example"; // String | startDate
Integer startPage = 56; // Integer | 
String type = "type_example"; // String | 
try {
    ApiResponseOfPageDataOfCard result = apiInstance.cardsUsingGET(authorization, cardStatus, endDate, last4, remark, row, startDate, startPage, type);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#cardsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardStatus** | **String**|  | [optional]
 **endDate** | **String**| endDate | [optional]
 **last4** | **String**|  | [optional]
 **remark** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**| startDate | [optional]
 **startPage** | **Integer**|  | [optional]
 **type** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfCard**](ApiResponseOfPageDataOfCard.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="chargeOutUsingPOST"></a>
# **chargeOutUsingPOST**
> ApiResponseOfstring chargeOutUsingPOST(authorization, cardOutRequest)

card balance fund transfer out to account balance

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardOutRequest cardOutRequest = new CardOutRequest(); // CardOutRequest | cardOutRequest
try {
    ApiResponseOfstring result = apiInstance.chargeOutUsingPOST(authorization, cardOutRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#chargeOutUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardOutRequest** | [**CardOutRequest**](CardOutRequest.md)| cardOutRequest |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="clearingsRecordUsingGET"></a>
# **clearingsRecordUsingGET**
> ApiResponseOfPageDataOfClear clearingsRecordUsingGET(authorization, createdEndDate, createdStartDate, postingEndDate, postingStartDate, ppCardId, row, startPage, type)

query  clearings record api by page

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String createdEndDate = "createdEndDate_example"; // String | createdEndDate
String createdStartDate = "createdStartDate_example"; // String | createdStartDate
String postingEndDate = "postingEndDate_example"; // String | postingEndDate
String postingStartDate = "postingStartDate_example"; // String | postingStartDate
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
Integer startPage = 56; // Integer | 
String type = "type_example"; // String | 
try {
    ApiResponseOfPageDataOfClear result = apiInstance.clearingsRecordUsingGET(authorization, createdEndDate, createdStartDate, postingEndDate, postingStartDate, ppCardId, row, startPage, type);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#clearingsRecordUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **createdEndDate** | **String**| createdEndDate | [optional]
 **createdStartDate** | **String**| createdStartDate | [optional]
 **postingEndDate** | **String**| postingEndDate | [optional]
 **postingStartDate** | **String**| postingStartDate | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startPage** | **Integer**|  | [optional]
 **type** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfClear**](ApiResponseOfPageDataOfClear.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="clearingsUsingGET"></a>
# **clearingsUsingGET**
> ApiResponseOfPageDataOfClear clearingsUsingGET(authorization, createdEndDate, createdStartDate, postingEndDate, postingStartDate, ppCardId, row, startPage, type)

query clearings api by page

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String createdEndDate = "createdEndDate_example"; // String | createdEndDate
String createdStartDate = "createdStartDate_example"; // String | createdStartDate
String postingEndDate = "postingEndDate_example"; // String | postingEndDate
String postingStartDate = "postingStartDate_example"; // String | postingStartDate
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
Integer startPage = 56; // Integer | 
String type = "type_example"; // String | 
try {
    ApiResponseOfPageDataOfClear result = apiInstance.clearingsUsingGET(authorization, createdEndDate, createdStartDate, postingEndDate, postingStartDate, ppCardId, row, startPage, type);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#clearingsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **createdEndDate** | **String**| createdEndDate | [optional]
 **createdStartDate** | **String**| createdStartDate | [optional]
 **postingEndDate** | **String**| postingEndDate | [optional]
 **postingStartDate** | **String**| postingStartDate | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startPage** | **Integer**|  | [optional]
 **type** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfClear**](ApiResponseOfPageDataOfClear.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getAvailableBalanceByPpCardIdUsingGET"></a>
# **getAvailableBalanceByPpCardIdUsingGET**
> ApiResponseOfCardData getAvailableBalanceByPpCardIdUsingGET(authorization, ppCardId)

query card balance by cardId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String ppCardId = "ppCardId_example"; // String | 
try {
    ApiResponseOfCardData result = apiInstance.getAvailableBalanceByPpCardIdUsingGET(authorization, ppCardId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#getAvailableBalanceByPpCardIdUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **ppCardId** | **String**|  | [optional]

### Return type

[**ApiResponseOfCardData**](ApiResponseOfCardData.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getFraudConfigUsingGET"></a>
# **getFraudConfigUsingGET**
> ModelApiResponse getFraudConfigUsingGET(authorization)

get fraud

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
try {
    ModelApiResponse result = apiInstance.getFraudConfigUsingGET(authorization);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#getFraudConfigUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |

### Return type

[**ModelApiResponse**](ModelApiResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryAccountBalance2UsingGET"></a>
# **queryAccountBalance2UsingGET**
> ApiResponseOfCardDetail2 queryAccountBalance2UsingGET(authorization, ppCardId)

query card detail by cardId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String ppCardId = "ppCardId_example"; // String | 
try {
    ApiResponseOfCardDetail2 result = apiInstance.queryAccountBalance2UsingGET(authorization, ppCardId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryAccountBalance2UsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **ppCardId** | **String**|  |

### Return type

[**ApiResponseOfCardDetail2**](ApiResponseOfCardDetail2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryAccountBalanceUsingGET"></a>
# **queryAccountBalanceUsingGET**
> ApiResponseOfAccountBalance queryAccountBalanceUsingGET(authorization, budgetId)

query normal account balance

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String budgetId = "budgetId_example"; // String | 
try {
    ApiResponseOfAccountBalance result = apiInstance.queryAccountBalanceUsingGET(authorization, budgetId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryAccountBalanceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **budgetId** | **String**|  | [optional]

### Return type

[**ApiResponseOfAccountBalance**](ApiResponseOfAccountBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryAllAccountBalanceUsingGET"></a>
# **queryAllAccountBalanceUsingGET**
> ApiResponseOfListOfAccountBalance queryAllAccountBalanceUsingGET(authorization, budgetId)

query all balance

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String budgetId = "budgetId_example"; // String | 
try {
    ApiResponseOfListOfAccountBalance result = apiInstance.queryAllAccountBalanceUsingGET(authorization, budgetId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryAllAccountBalanceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **budgetId** | **String**|  | [optional]

### Return type

[**ApiResponseOfListOfAccountBalance**](ApiResponseOfListOfAccountBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryCardOrderListUsingGET"></a>
# **queryCardOrderListUsingGET**
> ApiResponseOfPageDataOfOrder queryCardOrderListUsingGET(authorization, endDate, ppCardId, row, startDate, startPage, status, uniqueOrderId)

query card order list by page

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String endDate = "endDate_example"; // String | 
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "startDate_example"; // String | 
Integer startPage = 56; // Integer | 
String status = "status_example"; // String | 
String uniqueOrderId = "uniqueOrderId_example"; // String | 
try {
    ApiResponseOfPageDataOfOrder result = apiInstance.queryCardOrderListUsingGET(authorization, endDate, ppCardId, row, startDate, startPage, status, uniqueOrderId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryCardOrderListUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **endDate** | **String**|  | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**|  | [optional]
 **startPage** | **Integer**|  | [optional]
 **status** | **String**|  | [optional]
 **uniqueOrderId** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfOrder**](ApiResponseOfPageDataOfOrder.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryShareAccountBalanceUsingGET"></a>
# **queryShareAccountBalanceUsingGET**
> ApiResponseOfAccountBalance queryShareAccountBalanceUsingGET(authorization, budgetId)

query normal account balance

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String budgetId = "budgetId_example"; // String | 
try {
    ApiResponseOfAccountBalance result = apiInstance.queryShareAccountBalanceUsingGET(authorization, budgetId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryShareAccountBalanceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **budgetId** | **String**|  | [optional]

### Return type

[**ApiResponseOfAccountBalance**](ApiResponseOfAccountBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="rechargeUsingPOST"></a>
# **rechargeUsingPOST**
> ApiResponseOfstring rechargeUsingPOST(authorization, cardInRequest)

normal card recharge

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardInRequest cardInRequest = new CardInRequest(); // CardInRequest | cardInRequest
try {
    ApiResponseOfstring result = apiInstance.rechargeUsingPOST(authorization, cardInRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#rechargeUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardInRequest** | [**CardInRequest**](CardInRequest.md)| cardInRequest |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="setFraudConfigUsingPOST"></a>
# **setFraudConfigUsingPOST**
> ModelApiResponse setFraudConfigUsingPOST(authorization, request)

set fraud

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
SetFraudRequest request = new SetFraudRequest(); // SetFraudRequest | request
try {
    ModelApiResponse result = apiInstance.setFraudConfigUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#setFraudConfigUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**SetFraudRequest**](SetFraudRequest.md)| request |

### Return type

[**ModelApiResponse**](ModelApiResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="unblockUsingPOST"></a>
# **unblockUsingPOST**
> ApiResponseOfVoid unblockUsingPOST(authorization, cardUnBlockRequest)

unblock card api

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardUnBlockRequest cardUnBlockRequest = new CardUnBlockRequest(); // CardUnBlockRequest | cardUnBlockRequest
try {
    ApiResponseOfVoid result = apiInstance.unblockUsingPOST(authorization, cardUnBlockRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#unblockUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardUnBlockRequest** | [**CardUnBlockRequest**](CardUnBlockRequest.md)| cardUnBlockRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="updateCardLimitUsingPOST"></a>
# **updateCardLimitUsingPOST**
> ApiResponseOfVoid updateCardLimitUsingPOST(authorization, cardLimitRequest)

update share card limit details

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardLimitRequest cardLimitRequest = new CardLimitRequest(); // CardLimitRequest | cardLimitRequest
try {
    ApiResponseOfVoid result = apiInstance.updateCardLimitUsingPOST(authorization, cardLimitRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#updateCardLimitUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardLimitRequest** | [**CardLimitRequest**](CardLimitRequest.md)| cardLimitRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="updateCardRemarkUsingPOST"></a>
# **updateCardRemarkUsingPOST**
> ApiResponseOfVoid updateCardRemarkUsingPOST(authorization, request)

update card remark

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardRemarkRequest request = new CardRemarkRequest(); // CardRemarkRequest | request
try {
    ApiResponseOfVoid result = apiInstance.updateCardRemarkUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#updateCardRemarkUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**CardRemarkRequest**](CardRemarkRequest.md)| request |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

