
# PageDataOfOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_list** | [**List&lt;Order&gt;**](Order.md) |  |  [optional]
**total** | **Integer** |  |  [optional]



