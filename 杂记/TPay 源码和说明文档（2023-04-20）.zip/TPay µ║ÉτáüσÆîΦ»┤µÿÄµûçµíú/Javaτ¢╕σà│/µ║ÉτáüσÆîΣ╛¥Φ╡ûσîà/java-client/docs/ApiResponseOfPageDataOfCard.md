
# ApiResponseOfPageDataOfCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**PageDataOfCard**](PageDataOfCard.md) |  |  [optional]
**message** | **String** |  |  [optional]



