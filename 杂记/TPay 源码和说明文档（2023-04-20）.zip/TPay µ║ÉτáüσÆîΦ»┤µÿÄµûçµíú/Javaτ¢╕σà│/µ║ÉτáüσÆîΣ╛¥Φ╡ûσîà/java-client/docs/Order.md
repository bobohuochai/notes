
# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**created** | **String** |  |  [optional]
**currency** | **String** |  |  [optional]
**operateType** | **String** |  |  [optional]
**ppCardId** | **String** |  |  [optional]
**recordId** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**uniqueOrderId** | **String** |  |  [optional]



