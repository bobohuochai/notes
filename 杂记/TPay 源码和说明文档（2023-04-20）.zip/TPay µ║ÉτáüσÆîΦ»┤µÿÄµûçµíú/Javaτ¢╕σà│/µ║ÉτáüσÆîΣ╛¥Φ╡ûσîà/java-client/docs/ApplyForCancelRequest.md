
# ApplyForCancelRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operationRemark** | **String** |  |  [optional]
**ppCardId** | **String** |  | 



