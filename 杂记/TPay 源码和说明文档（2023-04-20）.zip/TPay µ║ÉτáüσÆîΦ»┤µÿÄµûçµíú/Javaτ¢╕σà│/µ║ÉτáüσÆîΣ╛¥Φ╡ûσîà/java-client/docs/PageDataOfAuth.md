
# PageDataOfAuth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_list** | [**List&lt;Auth&gt;**](Auth.md) |  |  [optional]
**total** | **Integer** |  |  [optional]



