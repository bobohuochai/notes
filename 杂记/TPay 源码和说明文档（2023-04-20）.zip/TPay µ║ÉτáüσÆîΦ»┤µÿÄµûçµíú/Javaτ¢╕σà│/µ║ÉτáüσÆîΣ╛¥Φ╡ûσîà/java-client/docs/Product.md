
# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowCardOut** | **Boolean** |  |  [optional]
**bannerUrlCn** | **String** |  |  [optional]
**bannerUrlEn** | **String** |  |  [optional]
**billingCurrency** | **String** |  |  [optional]
**cardCountLimit** | **Integer** |  |  [optional]
**cardHolderCustomizable** | **Boolean** |  |  [optional]
**cardNetWork** | **String** |  |  [optional]
**code** | **String** |  |  [optional]
**freeUntilConsume** | **String** |  |  [optional]
**htmlContent4Cn** | **List&lt;String&gt;** |  |  [optional]
**htmlContent4En** | **List&lt;String&gt;** |  |  [optional]
**initAmount** | **String** |  |  [optional]
**isSale** | **Boolean** |  |  [optional]
**nameCn** | **String** |  |  [optional]
**nameEn** | **String** |  |  [optional]
**offSaleNoticeCn** | **String** |  |  [optional]
**offSaleNoticeEn** | **String** |  |  [optional]
**oriPrice** | **String** |  |  [optional]
**price** | **String** |  |  [optional]
**sectionNo** | **String** |  |  [optional]
**share** | **Boolean** |  |  [optional]
**validMonth** | **Integer** |  |  [optional]



