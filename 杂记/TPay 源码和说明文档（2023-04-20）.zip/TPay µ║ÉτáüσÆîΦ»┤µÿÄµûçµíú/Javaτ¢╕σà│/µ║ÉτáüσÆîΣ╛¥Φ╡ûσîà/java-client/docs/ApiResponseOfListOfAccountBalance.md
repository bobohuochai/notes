
# ApiResponseOfListOfAccountBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**List&lt;AccountBalance&gt;**](AccountBalance.md) |  |  [optional]
**message** | **String** |  |  [optional]



