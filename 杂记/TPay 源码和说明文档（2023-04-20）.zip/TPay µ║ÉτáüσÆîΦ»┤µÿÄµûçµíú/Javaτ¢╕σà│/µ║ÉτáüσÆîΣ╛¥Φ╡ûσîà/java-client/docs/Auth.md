
# Auth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approvalCode** | **String** |  |  [optional]
**authorizationDate** | **String** |  |  [optional]
**authorizationId** | **String** |  |  [optional]
**authorizationStatus** | **String** |  |  [optional]
**authorizationType** | **String** |  |  [optional]
**billingAmount** | **String** |  |  [optional]
**billingCurrency** | **String** |  |  [optional]
**budgetId** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**failReason** | **String** |  |  [optional]
**mcc** | **String** |  |  [optional]
**merchantAmount** | **String** |  |  [optional]
**merchantCurrency** | **String** |  |  [optional]
**merchantName** | **String** |  |  [optional]
**ppCardId** | **String** |  |  [optional]
**rateFee** | **String** |  |  [optional]
**rateFeeCurrency** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]



