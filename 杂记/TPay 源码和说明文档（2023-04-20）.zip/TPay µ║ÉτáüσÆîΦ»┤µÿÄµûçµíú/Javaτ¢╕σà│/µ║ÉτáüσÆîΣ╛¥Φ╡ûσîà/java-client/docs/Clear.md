
# Clear

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billingAmount** | **String** |  |  [optional]
**billingCurrency** | **String** |  |  [optional]
**budgetId** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**last4** | **String** |  |  [optional]
**merchantAmount** | **String** |  |  [optional]
**merchantCurrency** | **String** |  |  [optional]
**merchantName** | **String** |  |  [optional]
**postingDate** | **String** |  |  [optional]
**ppCardId** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**transactionDate** | **String** |  |  [optional]
**transactionId** | **String** |  |  [optional]
**type** | **String** |  |  [optional]



