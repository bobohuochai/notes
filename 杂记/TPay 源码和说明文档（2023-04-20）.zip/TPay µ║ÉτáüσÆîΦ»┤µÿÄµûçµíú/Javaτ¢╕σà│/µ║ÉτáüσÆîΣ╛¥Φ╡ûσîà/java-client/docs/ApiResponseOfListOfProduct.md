
# ApiResponseOfListOfProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]
**message** | **String** |  |  [optional]



