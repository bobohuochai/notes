
# PageDataOfCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_list** | [**List&lt;Card&gt;**](Card.md) |  |  [optional]
**total** | **Integer** |  |  [optional]



