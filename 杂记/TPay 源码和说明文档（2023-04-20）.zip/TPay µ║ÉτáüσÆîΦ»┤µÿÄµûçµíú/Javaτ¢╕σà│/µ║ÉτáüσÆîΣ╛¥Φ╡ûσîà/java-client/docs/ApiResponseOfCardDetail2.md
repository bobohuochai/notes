
# ApiResponseOfCardDetail2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**CardDetail2**](CardDetail2.md) |  |  [optional]
**message** | **String** |  |  [optional]



