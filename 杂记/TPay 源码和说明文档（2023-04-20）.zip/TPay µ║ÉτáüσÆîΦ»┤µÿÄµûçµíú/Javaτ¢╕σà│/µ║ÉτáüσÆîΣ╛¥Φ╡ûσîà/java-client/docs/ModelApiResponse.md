
# ModelApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | **Object** |  |  [optional]
**message** | **String** |  |  [optional]



