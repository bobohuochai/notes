
# ApiResponseOfPageDataOfOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**PageDataOfOrder**](PageDataOfOrder.md) |  |  [optional]
**message** | **String** |  |  [optional]



