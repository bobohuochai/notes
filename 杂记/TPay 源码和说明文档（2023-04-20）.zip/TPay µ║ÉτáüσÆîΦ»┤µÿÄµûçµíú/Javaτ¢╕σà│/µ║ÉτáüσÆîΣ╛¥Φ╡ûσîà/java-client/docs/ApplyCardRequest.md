
# ApplyCardRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardProductCode** | **String** |  | 
**requestId** | **String** |  | 
**share** | **Boolean** |  | 
**useECard** | **Boolean** |  | 
**cardUsage** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**singleLimit** | **String** |  |  [optional]
**dailyLimit** | **String** |  |  [optional]
**weeklyLimit** | **String** |  |  [optional]
**monthlyLimit** | **String** |  |  [optional]
**totalLimit** | **String** |  |  [optional]
**budgetId** | **String** |  |  [optional]



