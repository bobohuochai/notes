
# CardLimitRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  | 
**ppCardId** | **String** |  | 
**type** | **String** |  | 



