
# CardDetail2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowCardOut** | **String** |  |  [optional]
**applyForCancellation** | **String** |  |  [optional]
**billingCurrency** | **String** |  |  [optional]
**budgetId** | **String** |  |  [optional]
**cancellationInAdvance** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**cardStatus** | **String** |  |  [optional]
**created** | **String** |  |  [optional]
**cvc** | **String** |  |  [optional]
**dayAmountLimit** | **String** |  |  [optional]
**expiry** | **String** |  |  [optional]
**monthAmountLimit** | **String** |  |  [optional]
**ppCardId** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**totalAmountLimit** | **String** |  |  [optional]
**transactionAmountLimit** | **String** |  |  [optional]
**type** | **String** |  |  [optional]
**weekAmountLimit** | **String** |  |  [optional]



