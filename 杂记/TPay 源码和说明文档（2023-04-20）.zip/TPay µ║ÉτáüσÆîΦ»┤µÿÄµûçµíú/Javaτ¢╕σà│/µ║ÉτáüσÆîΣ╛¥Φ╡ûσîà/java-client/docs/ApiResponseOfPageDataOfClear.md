
# ApiResponseOfPageDataOfClear

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**PageDataOfClear**](PageDataOfClear.md) |  |  [optional]
**message** | **String** |  |  [optional]



