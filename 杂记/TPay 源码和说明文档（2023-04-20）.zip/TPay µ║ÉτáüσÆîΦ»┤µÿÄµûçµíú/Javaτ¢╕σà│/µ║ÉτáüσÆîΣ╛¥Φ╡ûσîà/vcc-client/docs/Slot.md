
# Slot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restSlot** | **Integer** |  |  [optional]



