
# AccountBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **String** |  |  [optional]
**currency** | **String** |  |  [optional]



