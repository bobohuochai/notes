# PingPongIssuingOpenApiV2Api

All URIs are relative to *https://localhost:8031*

Method | HTTP request | Description
------------- | ------------- | -------------
[**applyCardUsingPOST**](PingPongIssuingOpenApiV2Api.md#applyCardUsingPOST) | **POST** /v2/vcc/open/card/apply | apply card api
[**authorizationsUsingGET**](PingPongIssuingOpenApiV2Api.md#authorizationsUsingGET) | **GET** /v2/vcc/open/authorizations | query authorizations api by page
[**blockUsingPOST**](PingPongIssuingOpenApiV2Api.md#blockUsingPOST) | **POST** /v2/vcc/open/card/block | block card api
[**cardProductListUsingGET**](PingPongIssuingOpenApiV2Api.md#cardProductListUsingGET) | **GET** /v2/vcc/open/card/product | query card product
[**cardsUsingGET**](PingPongIssuingOpenApiV2Api.md#cardsUsingGET) | **GET** /v2/vcc/open/cards | query card list by page
[**chargeOutUsingPOST**](PingPongIssuingOpenApiV2Api.md#chargeOutUsingPOST) | **POST** /v2/vcc/open/card/order/charge-out | card balance fund transfer out to account balance
[**clearingsUsingGET**](PingPongIssuingOpenApiV2Api.md#clearingsUsingGET) | **GET** /v2/vcc/open/clearings | query clearings api by page
[**getAvailableBalanceByPpCardIdUsingGET**](PingPongIssuingOpenApiV2Api.md#getAvailableBalanceByPpCardIdUsingGET) | **GET** /v2/vcc/open/card/balance | query card balance by cardId
[**queryAccountBalanceUsingGET**](PingPongIssuingOpenApiV2Api.md#queryAccountBalanceUsingGET) | **GET** /v2/vcc/open/account/balance | query normal account balance
[**queryCardDetailUsingGET**](PingPongIssuingOpenApiV2Api.md#queryCardDetailUsingGET) | **GET** /v2/vcc/open/card/detail | query card detail by cardId
[**queryCardOrderListUsingGET**](PingPongIssuingOpenApiV2Api.md#queryCardOrderListUsingGET) | **GET** /v2/vcc/open/card/order/list | query card order list by page
[**queryShareAccountBalanceUsingGET**](PingPongIssuingOpenApiV2Api.md#queryShareAccountBalanceUsingGET) | **GET** /v2/vcc/open/account/share/balance | query normal account balance
[**rechargeUsingPOST**](PingPongIssuingOpenApiV2Api.md#rechargeUsingPOST) | **POST** /v2/vcc/open/card/order/recharge | normal card recharge
[**slotNormalUsingGET**](PingPongIssuingOpenApiV2Api.md#slotNormalUsingGET) | **GET** /v2/vcc/open/slot/normal | query card apply limit remain for normal account
[**slotShareUsingGET**](PingPongIssuingOpenApiV2Api.md#slotShareUsingGET) | **GET** /v2/vcc/open/slot/share | query card apply limit remain for share account
[**unblockUsingPOST**](PingPongIssuingOpenApiV2Api.md#unblockUsingPOST) | **POST** /v2/vcc/open/card/unblock | unblock card api
[**updateCardLimitUsingPOST**](PingPongIssuingOpenApiV2Api.md#updateCardLimitUsingPOST) | **POST** /v2/vcc/open/share/card/limit | update share card limit details
[**updateCardRemarkUsingPOST**](PingPongIssuingOpenApiV2Api.md#updateCardRemarkUsingPOST) | **POST** /v2/vcc/open/card/remark | update card remark


<a name="applyCardUsingPOST"></a>
# **applyCardUsingPOST**
> ApiResponseOfstring applyCardUsingPOST(authorization, request)

apply card api

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
ApplyCardRequest request = new ApplyCardRequest(); // ApplyCardRequest | request
try {
    ApiResponseOfstring result = apiInstance.applyCardUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#applyCardUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**ApplyCardRequest**](ApplyCardRequest.md)| request |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="authorizationsUsingGET"></a>
# **authorizationsUsingGET**
> ApiResponseOfPageDataOfAuth authorizationsUsingGET(authorization, endDate, ppCardId, row, startDate, startPage)

query authorizations api by page

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String endDate = "yyyy-MM-dd HH:mm:ss"; // String | endDate
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "yyyy-MM-dd HH:mm:ss"; // String | startDate
Integer startPage = 56; // Integer | 
try {
    ApiResponseOfPageDataOfAuth result = apiInstance.authorizationsUsingGET(authorization, endDate, ppCardId, row, startDate, startPage);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#authorizationsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **endDate** | **String**| endDate | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**| startDate | [optional]
 **startPage** | **Integer**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfAuth**](ApiResponseOfPageDataOfAuth.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="blockUsingPOST"></a>
# **blockUsingPOST**
> ApiResponseOfVoid blockUsingPOST(authorization, cardBlockRequest)

block card api

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardBlockRequest cardBlockRequest = new CardBlockRequest(); // CardBlockRequest | cardBlockRequest
try {
    ApiResponseOfVoid result = apiInstance.blockUsingPOST(authorization, cardBlockRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#blockUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardBlockRequest** | [**CardBlockRequest**](CardBlockRequest.md)| cardBlockRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="cardProductListUsingGET"></a>
# **cardProductListUsingGET**
> ApiResponseOfListOfProduct cardProductListUsingGET(authorization, share)

query card product

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
Boolean share = true; // Boolean | 
try {
    ApiResponseOfListOfProduct result = apiInstance.cardProductListUsingGET(authorization, share);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#cardProductListUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **share** | **Boolean**|  |

### Return type

[**ApiResponseOfListOfProduct**](ApiResponseOfListOfProduct.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="cardsUsingGET"></a>
# **cardsUsingGET**
> ApiResponseOfPageDataOfCard cardsUsingGET(authorization, cardStatus, endDate, last4, remark, row, startDate, startPage, type)

query card list by page

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String cardStatus = "cardStatus_example"; // String | 
String endDate = "yyyy-MM-dd HH:mm:ss"; // String | endDate
String last4 = "last4_example"; // String | 
String remark = "remark_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "yyyy-MM-dd HH:mm:ss"; // String | startDate
Integer startPage = 56; // Integer | 
String type = "type_example"; // String | 
try {
    ApiResponseOfPageDataOfCard result = apiInstance.cardsUsingGET(authorization, cardStatus, endDate, last4, remark, row, startDate, startPage, type);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#cardsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardStatus** | **String**|  | [optional]
 **endDate** | **String**| endDate | [optional]
 **last4** | **String**|  | [optional]
 **remark** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**| startDate | [optional]
 **startPage** | **Integer**|  | [optional]
 **type** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfCard**](ApiResponseOfPageDataOfCard.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="chargeOutUsingPOST"></a>
# **chargeOutUsingPOST**
> ApiResponseOfstring chargeOutUsingPOST(authorization, cardOutRequest)

card balance fund transfer out to account balance

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardOutRequest cardOutRequest = new CardOutRequest(); // CardOutRequest | cardOutRequest
try {
    ApiResponseOfstring result = apiInstance.chargeOutUsingPOST(authorization, cardOutRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#chargeOutUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardOutRequest** | [**CardOutRequest**](CardOutRequest.md)| cardOutRequest |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="clearingsUsingGET"></a>
# **clearingsUsingGET**
> ApiResponseOfPageDataOfClear clearingsUsingGET(authorization, postingEndDate, postingStartDate, ppCardId, row, startPage)

query clearings api by page

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String postingEndDate = "yyyy-MM-dd HH:mm:ss"; // String | postingEndDate
String postingStartDate = "yyyy-MM-dd HH:mm:ss"; // String | postingStartDate
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
Integer startPage = 56; // Integer | 
try {
    ApiResponseOfPageDataOfClear result = apiInstance.clearingsUsingGET(authorization, postingEndDate, postingStartDate, ppCardId, row, startPage);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#clearingsUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **postingEndDate** | **String**| postingEndDate | [optional]
 **postingStartDate** | **String**| postingStartDate | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startPage** | **Integer**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfClear**](ApiResponseOfPageDataOfClear.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getAvailableBalanceByPpCardIdUsingGET"></a>
# **getAvailableBalanceByPpCardIdUsingGET**
> ApiResponseOfCardData getAvailableBalanceByPpCardIdUsingGET(authorization, ppCardId)

query card balance by cardId

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String ppCardId = "ppCardId_example"; // String | 
try {
    ApiResponseOfCardData result = apiInstance.getAvailableBalanceByPpCardIdUsingGET(authorization, ppCardId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#getAvailableBalanceByPpCardIdUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **ppCardId** | **String**|  | [optional]

### Return type

[**ApiResponseOfCardData**](ApiResponseOfCardData.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryAccountBalanceUsingGET"></a>
# **queryAccountBalanceUsingGET**
> ApiResponseOfAccountBalance queryAccountBalanceUsingGET(authorization)

query normal account balance

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
try {
    ApiResponseOfAccountBalance result = apiInstance.queryAccountBalanceUsingGET(authorization);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryAccountBalanceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |

### Return type

[**ApiResponseOfAccountBalance**](ApiResponseOfAccountBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryCardDetailUsingGET"></a>
# **queryCardDetailUsingGET**
> ApiResponseOfCardDetail2 queryCardDetailUsingGET(authorization, ppCardId)

query card detail by cardId

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String ppCardId = "ppCardId_example"; // String | 
try {
    ApiResponseOfCardDetail2 result = apiInstance.queryCardDetailUsingGET(authorization, ppCardId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryCardDetailUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **ppCardId** | **String**|  |

### Return type

[**ApiResponseOfCardDetail2**](ApiResponseOfCardDetail2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryCardOrderListUsingGET"></a>
# **queryCardOrderListUsingGET**
> ApiResponseOfPageDataOfOrder queryCardOrderListUsingGET(authorization, endDate, ppCardId, row, startDate, startPage, status, uniqueOrderId)

query card order list by page

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
String endDate = "endDate_example"; // String | 
String ppCardId = "ppCardId_example"; // String | 
Integer row = 56; // Integer | 
String startDate = "startDate_example"; // String | 
Integer startPage = 56; // Integer | 
String status = "status_example"; // String | 
String uniqueOrderId = "uniqueOrderId_example"; // String | 
try {
    ApiResponseOfPageDataOfOrder result = apiInstance.queryCardOrderListUsingGET(authorization, endDate, ppCardId, row, startDate, startPage, status, uniqueOrderId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryCardOrderListUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **endDate** | **String**|  | [optional]
 **ppCardId** | **String**|  | [optional]
 **row** | **Integer**|  | [optional]
 **startDate** | **String**|  | [optional]
 **startPage** | **Integer**|  | [optional]
 **status** | **String**|  | [optional]
 **uniqueOrderId** | **String**|  | [optional]

### Return type

[**ApiResponseOfPageDataOfOrder**](ApiResponseOfPageDataOfOrder.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="queryShareAccountBalanceUsingGET"></a>
# **queryShareAccountBalanceUsingGET**
> ApiResponseOfAccountBalance queryShareAccountBalanceUsingGET(authorization)

query normal account balance

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
try {
    ApiResponseOfAccountBalance result = apiInstance.queryShareAccountBalanceUsingGET(authorization);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#queryShareAccountBalanceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |

### Return type

[**ApiResponseOfAccountBalance**](ApiResponseOfAccountBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="rechargeUsingPOST"></a>
# **rechargeUsingPOST**
> ApiResponseOfstring rechargeUsingPOST(authorization, cardInRequest)

normal card recharge

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardInRequest cardInRequest = new CardInRequest(); // CardInRequest | cardInRequest
try {
    ApiResponseOfstring result = apiInstance.rechargeUsingPOST(authorization, cardInRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#rechargeUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardInRequest** | [**CardInRequest**](CardInRequest.md)| cardInRequest |

### Return type

[**ApiResponseOfstring**](ApiResponseOfstring.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="slotNormalUsingGET"></a>
# **slotNormalUsingGET**
> ApiResponseOfSlot slotNormalUsingGET(authorization)

query card apply limit remain for normal account

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
try {
    ApiResponseOfSlot result = apiInstance.slotNormalUsingGET(authorization);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#slotNormalUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |

### Return type

[**ApiResponseOfSlot**](ApiResponseOfSlot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="slotShareUsingGET"></a>
# **slotShareUsingGET**
> ApiResponseOfSlot slotShareUsingGET(authorization)

query card apply limit remain for share account

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
try {
    ApiResponseOfSlot result = apiInstance.slotShareUsingGET(authorization);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#slotShareUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |

### Return type

[**ApiResponseOfSlot**](ApiResponseOfSlot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="unblockUsingPOST"></a>
# **unblockUsingPOST**
> ApiResponseOfVoid unblockUsingPOST(authorization, cardUnBlockRequest)

unblock card api

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardUnBlockRequest cardUnBlockRequest = new CardUnBlockRequest(); // CardUnBlockRequest | cardUnBlockRequest
try {
    ApiResponseOfVoid result = apiInstance.unblockUsingPOST(authorization, cardUnBlockRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#unblockUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardUnBlockRequest** | [**CardUnBlockRequest**](CardUnBlockRequest.md)| cardUnBlockRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="updateCardLimitUsingPOST"></a>
# **updateCardLimitUsingPOST**
> ApiResponseOfVoid updateCardLimitUsingPOST(authorization, cardLimitRequest)

update share card limit details

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardLimitRequest cardLimitRequest = new CardLimitRequest(); // CardLimitRequest | cardLimitRequest
try {
    ApiResponseOfVoid result = apiInstance.updateCardLimitUsingPOST(authorization, cardLimitRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#updateCardLimitUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **cardLimitRequest** | [**CardLimitRequest**](CardLimitRequest.md)| cardLimitRequest |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="updateCardRemarkUsingPOST"></a>
# **updateCardRemarkUsingPOST**
> ApiResponseOfVoid updateCardRemarkUsingPOST(authorization, request)

update card remark

### Example
```java
// Import classes:
//import com.pingpongx.vcc.client.ApiException;
//import com.pingpongx.vcc.api.PingPongIssuingOpenApiV2Api;


PingPongIssuingOpenApiV2Api apiInstance = new PingPongIssuingOpenApiV2Api();
String authorization = "authorization_example"; // String | access_token
CardRemarkRequest request = new CardRemarkRequest(); // CardRemarkRequest | request
try {
    ApiResponseOfVoid result = apiInstance.updateCardRemarkUsingPOST(authorization, request);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PingPongIssuingOpenApiV2Api#updateCardRemarkUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**| access_token |
 **request** | [**CardRemarkRequest**](CardRemarkRequest.md)| request |

### Return type

[**ApiResponseOfVoid**](ApiResponseOfVoid.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

