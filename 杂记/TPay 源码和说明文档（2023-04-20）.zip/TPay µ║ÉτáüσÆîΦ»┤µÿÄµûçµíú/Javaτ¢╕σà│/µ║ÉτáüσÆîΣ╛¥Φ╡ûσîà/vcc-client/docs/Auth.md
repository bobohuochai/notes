
# Auth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorizationDate** | **String** |  |  [optional]
**authorizationId** | **String** |  |  [optional]
**authorizationStatus** | **String** |  |  [optional]
**authorizationType** | **String** |  |  [optional]
**billingAmount** | **String** |  |  [optional]
**billingCurrency** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**failReason** | **String** |  |  [optional]
**merchantName** | **String** |  |  [optional]



