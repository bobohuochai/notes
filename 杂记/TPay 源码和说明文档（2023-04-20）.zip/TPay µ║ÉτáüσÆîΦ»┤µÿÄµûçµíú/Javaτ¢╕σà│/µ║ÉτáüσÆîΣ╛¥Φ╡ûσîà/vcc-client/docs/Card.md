
# Card

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowCardOut** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**cardStatus** | **String** |  |  [optional]
**created** | **String** |  |  [optional]
**ppCardId** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**type** | **String** |  |  [optional]



