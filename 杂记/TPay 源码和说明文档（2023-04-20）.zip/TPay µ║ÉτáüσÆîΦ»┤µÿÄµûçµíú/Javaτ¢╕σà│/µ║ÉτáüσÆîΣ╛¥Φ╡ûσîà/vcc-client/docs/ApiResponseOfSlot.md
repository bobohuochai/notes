
# ApiResponseOfSlot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**data** | [**Slot**](Slot.md) |  |  [optional]
**message** | **String** |  |  [optional]



